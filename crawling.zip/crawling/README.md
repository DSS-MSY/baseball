# baseball
prediction of a baseball player who can hit tommorrow
