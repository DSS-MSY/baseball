#config settings
DB_TYPE = "postgresql://"
DB_USER = "postgres"
DB_PASSWORD = "1234"
DB_URL = "localhost"
DB_PORT = "5432"
DB_NAME = "baseball"
QUERY_ECHO = False
